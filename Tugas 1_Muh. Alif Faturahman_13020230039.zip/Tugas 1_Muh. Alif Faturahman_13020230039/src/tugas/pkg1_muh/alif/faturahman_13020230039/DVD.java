/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas.pkg1_muh.alif.faturahman_13020230039;


// DVD.java
/**
 * Class DVD sebagai turunan dari Item untuk merepresentasikan DVD
 */
public class DVD extends Item {
    private int durasi;
    private String sutradara;
    private String rating;

    /**
     * Constructor untuk inisialisasi objek DVD
     */
    public DVD(String id, String judul, int tahunTerbit, 
              int durasi, String sutradara, String rating) {
        super(id, judul, tahunTerbit);
        this.durasi = durasi;
        this.sutradara = sutradara;
        this.rating = rating;
    }

    // Getter methods
    public int getDurasi() { return durasi; }
    public String getSutradara() { return sutradara; }
    public String getRating() { return rating; }

    /**
     * Method override untuk menampilkan informasi lengkap DVD
     */
    @Override
    public void displayInfo() {
    super.displayInfo(); //*memanggil dan menjalankan method dari parent class
        System.out.println("Durasi: " + durasi + " menit");
        System.out.println("Sutradara: " + sutradara);
        System.out.println("Rating: " + rating);
    }

    /**
     * Method khusus untuk memutar DVD
     */
    public void putar() {
        System.out.println("Memutar DVD " + getJudul() + " dengan durasi " + durasi + " menit");
    }
}
